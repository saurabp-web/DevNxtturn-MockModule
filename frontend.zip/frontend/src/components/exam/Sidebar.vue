<template>
  <aside class="panel filters-panel">
    <h3>Filters</h3>

    <div class="filter-scroll-area">
    <!-- 1. Exam Level -->
    <div class="filter-group">
      <label>Exam Type</label>
      <div class="filter-dropdown" :class="{ 'filter-dropdown--open': openFilter === 'examLevel' }">
        <button type="button" class="filter-dropdown-trigger" @click="toggleFilter('examLevel')">
          <span>{{ examLevelLabel }}</span>
          <svg
            class="filter-dropdown-chevron"
            :class="{ 'filter-dropdown-chevron--open': openFilter === 'examLevel' }"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
          >
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </button>
        <div v-if="openFilter === 'examLevel'" class="filter-dropdown-panel">
          <label v-for="opt in examLevelOptions" :key="opt.value" class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.examLevel === opt.value"
              @change="selectExamLevel(opt.value)"
            />
            <span>{{ opt.label }}</span>
          </label>
        </div>
      </div>
    </div>

    <!-- 1b. Job Type — shown only when Job Exam is selected -->
    <div class="filter-group" v-if="local.examLevel === 'job'">
      <label>Job Type</label>
      <div class="filter-dropdown" :class="{ 'filter-dropdown--open': openFilter === 'jobType' }">
        <button type="button" class="filter-dropdown-trigger" @click="toggleFilter('jobType')">
          <span>{{ jobTypeLabel }}</span>
          <svg
            class="filter-dropdown-chevron"
            :class="{ 'filter-dropdown-chevron--open': openFilter === 'jobType' }"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
          >
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </button>
        <div v-if="openFilter === 'jobType'" class="filter-dropdown-panel">
          <label v-for="opt in jobTypeOptions" :key="opt.value" class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.jobType === opt.value"
              @change="selectJobType(opt.value)"
            />
            <span>{{ opt.label }}</span>
          </label>
        </div>
      </div>
    </div>

    <!-- 1c. Job Category — shown only when a Job Type is selected and has categories -->
    <div class="filter-group" v-if="activeJobCategories.length > 0">
      <label>Job Category</label>
      <div class="filter-dropdown" :class="{ 'filter-dropdown--open': openFilter === 'jobCategory' }">
        <button type="button" class="filter-dropdown-trigger" @click="toggleFilter('jobCategory')">
          <span>{{ jobCategoryLabel }}</span>
          <svg
            class="filter-dropdown-chevron"
            :class="{ 'filter-dropdown-chevron--open': openFilter === 'jobCategory' }"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
          >
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </button>
        <div v-if="openFilter === 'jobCategory'" class="filter-dropdown-panel">
          <label class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.jobCategory === ''"
              @change="selectJobCategory('')"
            />
            <span>All</span>
          </label>
          <label v-for="opt in activeJobCategories" :key="opt.value" class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.jobCategory === opt.value"
              @change="selectJobCategory(opt.value)"
            />
            <span>{{ opt.label }}</span>
          </label>
        </div>
      </div>
    </div>

    <!-- 2. Education Level -->
    <div class="filter-group">
      <label>Education Type</label>
      <div class="filter-dropdown" :class="{ 'filter-dropdown--open': openFilter === 'educationLevel' }">
        <button type="button" class="filter-dropdown-trigger" @click="toggleFilter('educationLevel')">
          <span>{{ educationLevelLabel }}</span>
          <svg
            class="filter-dropdown-chevron"
            :class="{ 'filter-dropdown-chevron--open': openFilter === 'educationLevel' }"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
          >
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </button>
        <div v-if="openFilter === 'educationLevel'" class="filter-dropdown-panel">
          <label v-for="opt in educationLevelOptions" :key="opt.value" class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.educationLevel === opt.value"
              @change="selectEducationLevel(opt.value)"
            />
            <span>{{ opt.label }}</span>
          </label>
        </div>
      </div>
    </div>

    <!-- 3. Graduation — shown only when relevant to the selected education level -->
    <div class="filter-group" v-if="activeGraduations.length > 0">
      <label>Graduation</label>
      <div class="filter-dropdown" :class="{ 'filter-dropdown--open': openFilter === 'graduation' }">
        <button type="button" class="filter-dropdown-trigger" @click="toggleFilter('graduation')">
          <span>{{ graduationLabel }}</span>
          <svg
            class="filter-dropdown-chevron"
            :class="{ 'filter-dropdown-chevron--open': openFilter === 'graduation' }"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
          >
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </button>
        <div v-if="openFilter === 'graduation'" class="filter-dropdown-panel">
          <label class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.graduation === ''"
              @change="selectGraduation('')"
            />
            <span>All</span>
          </label>
          <label v-for="opt in activeGraduations" :key="opt.value" class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.graduation === opt.value"
              @change="selectGraduation(opt.value)"
            />
            <span>{{ opt.label }}</span>
          </label>
        </div>
      </div>
    </div>

    <!-- 4. Engineering Status — only for Engineering qualification -->
    <div class="filter-group" v-if="local.educationLevel === 'engineering'">
      <label>Engineering Status</label>
      <div class="filter-dropdown" :class="{ 'filter-dropdown--open': openFilter === 'engineeringStatus' }">
        <button type="button" class="filter-dropdown-trigger" @click="toggleFilter('engineeringStatus')">
          <span>{{ engineeringStatusLabel }}</span>
          <svg
            class="filter-dropdown-chevron"
            :class="{ 'filter-dropdown-chevron--open': openFilter === 'engineeringStatus' }"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
          >
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </button>
        <div v-if="openFilter === 'engineeringStatus'" class="filter-dropdown-panel">
          <label v-for="opt in engineeringStatusOptions" :key="opt.value" class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.engineeringStatus === opt.value"
              @change="selectEngineeringStatus(opt.value)"
            />
            <span>{{ opt.label }}</span>
          </label>
        </div>
      </div>
    </div>

    <!-- 5. Stream / Engineering Branch — shown once streams exist for the selected
         education level AND, when this education level has a Graduation choice
         to make, only after Graduation has actually been picked. -->
    <div class="filter-group" v-if="activeStreams.length > 0 && (activeGraduations.length === 0 || local.graduation !== '')">
      <label>{{ streamGroupLabel }}</label>
      <div class="filter-dropdown" :class="{ 'filter-dropdown--open': openFilter === 'stream' }">
        <button type="button" class="filter-dropdown-trigger" @click="toggleFilter('stream')">
          <span>{{ streamLabel }}</span>
          <svg
            class="filter-dropdown-chevron"
            :class="{ 'filter-dropdown-chevron--open': openFilter === 'stream' }"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
          >
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </button>
        <div v-if="openFilter === 'stream'" class="filter-dropdown-panel">
          <label class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.stream === ''"
              @change="selectStream('')"
            />
            <span>All</span>
          </label>
          <label v-for="opt in activeStreams" :key="opt.value" class="filter-checkbox-row">
            <input
              type="checkbox"
              class="filter-checkbox"
              :checked="local.stream === opt.value"
              @change="selectStream(opt.value)"
            />
            <span>{{ opt.label }}</span>
          </label>
        </div>
      </div>
    </div>

    </div> <!-- end filter-scroll-area -->

    <div class="filter-actions">
      <button class="reset-btn" @click="resetFilters">Reset</button>
      <button class="apply-btn" @click="applyFilters">Apply Filters</button>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { reactive, computed, ref, onMounted, onBeforeUnmount } from 'vue'
import type { ExamFilters } from '../../types/exam'

const emit = defineEmits<{
  (e: 'change', filters: ExamFilters): void
  (e: 'apply'): void
}>()

// ── Types ────────────────────────────────────────────────────────────────────

interface Option { label: string; value: string }

interface SidebarState {
  examLevel: string
  jobType: string
  jobCategory: string
  educationLevel: string
  stream: string
  graduation: string
  engineeringStatus: string
}

// ── Stream options — keyed by Education Level ─────────────────────────────────

const STREAM_MAP: Record<string, Option[]> = {
  '10th': [
    { label: 'Science',        value: 'science' },
    { label: 'Mathematics',    value: 'maths' },
    { label: 'Social Science', value: 'social' },
  ],
  '12th': [
    { label: 'Science (PCM / PCB)', value: 'science' },
    { label: 'Commerce',            value: 'commerce' },
    { label: 'Arts / Humanities',   value: 'arts' },
  ],
  diploma: [
    { label: 'Mechanical',   value: 'mechanical' },
    { label: 'Civil',        value: 'civil' },
    { label: 'Electrical',   value: 'electrical' },
    { label: 'Computer',     value: 'computer' },
    { label: 'Electronics',  value: 'electronics' },
  ],
  engineering: [
    { label: 'Computer Science (CSE)',      value: 'cse' },
    { label: 'Mechanical Engineering',      value: 'mechanical' },
    { label: 'Civil Engineering',           value: 'civil' },
    { label: 'Electrical Engineering',      value: 'electrical' },
    { label: 'Electronics & Comm. (ECE)',   value: 'ece' },
    { label: 'Information Technology (IT)', value: 'it' },
    { label: 'Chemical Engineering',        value: 'chemical' },
    { label: 'Aerospace Engineering',       value: 'aerospace' },
  ],
  graduation: [
    { label: 'BA',           value: 'ba' },
    { label: 'B.Sc',         value: 'bsc' },
    { label: 'B.Com',        value: 'bcom' },
    { label: 'BBA',          value: 'bba' },
    { label: 'BCA',          value: 'bca' },
    { label: 'LLB',          value: 'llb' },
    { label: 'MBBS',         value: 'mbbs' },
    { label: 'B.Tech / BE',  value: 'btech' },
  ],
  pg: [
    { label: 'M.Tech / ME', value: 'mtech' },
    { label: 'M.Sc',        value: 'msc' },
    { label: 'MBA',         value: 'mba' },
    { label: 'MCA',         value: 'mca' },
    { label: 'MA',          value: 'ma' },
    { label: 'M.Com',       value: 'mcom' },
    { label: 'LLM',         value: 'llm' },
  ],
}

// ── Graduation options — keyed by Education Level ─────────────────────────────
// Only shown for levels where UG / PG distinction is relevant.
// 10th, 12th, diploma → no graduation filter shown.

const GRADUATION_MAP: Record<string, Option[]> = {
  '': [
    { label: 'UG', value: 'ug' },
    { label: 'PG', value: 'pg' },
  ],
  engineering: [
    { label: 'UG (B.Tech / BE)',  value: 'ug' },
    { label: 'PG (M.Tech / ME)',  value: 'pg' },
  ],
  graduation: [
    { label: 'UG', value: 'ug' },
  ],
  pg: [
    { label: 'PG', value: 'pg' },
  ],
}

// ── Static option lists for the top-level dropdowns ────────────────────────────

const examLevelOptions: Option[] = [
  { label: 'All',               value: '' },
  { label: 'Entrance Exam',        value: 'entrance' },
  { label: 'Job Exam',          value: 'job' },
  { label: 'School Level Exam', value: 'school' },
]

const jobTypeOptions: Option[] = [
  { label: 'All',              value: '' },
  { label: 'Government Exam',  value: 'government' },
  { label: 'IT Sector',        value: 'it' },
  { label: 'Non-IT Sector',    value: 'non_it' },
  { label: 'Private Sector',   value: 'private' },
]

// Job categories keyed by jobType — shown only when a job type is selected
const JOB_CATEGORY_MAP: Record<string, Option[]> = {
  government: [
    { label: 'Banking',          value: 'banking' },
    { label: 'Railways',         value: 'railways' },
    { label: 'Defence / Armed Forces', value: 'defence' },
    { label: 'Civil Services',   value: 'civil_services' },
    { label: 'SSC / Staff Selection', value: 'ssc' },
    { label: 'Teaching',         value: 'teaching' },
    { label: 'Medical / Health', value: 'medical' },
    { label: 'Agriculture',      value: 'agriculture' },
    { label: 'Police',           value: 'police' },
    { label: 'Insurance',        value: 'insurance' },
    { label: 'PSU / Engineering',value: 'psu' },
    { label: 'Law / Legal',      value: 'law' },
  ],
  it: [
    { label: 'Software Development', value: 'software' },
    { label: 'Data Science / AI',    value: 'data_science' },
    { label: 'Networking / Cloud',   value: 'networking' },
    { label: 'Cybersecurity',        value: 'cybersecurity' },
    { label: 'Testing / QA',         value: 'testing' },
  ],
  non_it: [
    { label: 'Finance / Accounting', value: 'finance' },
    { label: 'Marketing / Sales',    value: 'marketing' },
    { label: 'HR / Management',      value: 'hr' },
    { label: 'Operations / Logistics', value: 'operations' },
    { label: 'Medical / Healthcare', value: 'medical' },
    { label: 'Agriculture',          value: 'agriculture' },
    { label: 'Manufacturing',        value: 'manufacturing' },
  ],
  private: [
    { label: 'Finance / Accounting', value: 'finance' },
    { label: 'Marketing / Sales',    value: 'marketing' },
    { label: 'HR / Management',      value: 'hr' },
    { label: 'Media / Journalism',   value: 'media' },
    { label: 'Retail / FMCG',        value: 'retail' },
    { label: 'Hospitality / Tourism', value: 'hospitality' },
  ],
}

const educationLevelOptions: Option[] = [
  { label: 'All',              value: '' },
  { label: '10th',             value: '10th' },
  { label: '12th',             value: '12th' },
  { label: 'Diploma',          value: 'diploma' },
  { label: 'Engineering',      value: 'engineering' },
  { label: 'Graduation',       value: 'graduation' },
  { label: 'Post Graduation',  value: 'pg' },
]

const engineeringStatusOptions: Option[] = [
  { label: 'All',        value: '' },
  { label: 'Graduated',  value: 'graduated' },
  { label: 'Pursuing',   value: 'pursuing' },
]

// ── Local state ───────────────────────────────────────────────────────────────

function defaultState(): SidebarState {
  return {
    examLevel: '',
    jobType: '',
    jobCategory: '',
    educationLevel: '',
    stream: '',
    graduation: '',
    engineeringStatus: '',
  }
}

const local = reactive<SidebarState>(defaultState())

// ── Stream & Graduation lists driven by selected Education Level ──────────────

const activeStreams = computed<Option[]>(
  () => STREAM_MAP[local.educationLevel] ?? [],
)

const activeGraduations = computed<Option[]>(
  () => GRADUATION_MAP[local.educationLevel] ?? [],
)

const activeJobCategories = computed<Option[]>(
  () => (local.jobType ? JOB_CATEGORY_MAP[local.jobType] ?? [] : []),
)

// ── Selected-option labels shown on each dropdown trigger ─────────────────────

function labelFor(options: Option[], value: string): string {
  return options.find(o => o.value === value)?.label ?? 'All'
}

const examLevelLabel = computed(() => labelFor(examLevelOptions, local.examLevel))
const jobTypeLabel = computed(() => labelFor(jobTypeOptions, local.jobType))
const jobCategoryLabel = computed(() =>
  labelFor([{ label: 'All', value: '' }, ...activeJobCategories.value], local.jobCategory),
)
const educationLevelLabel = computed(() => labelFor(educationLevelOptions, local.educationLevel))
const engineeringStatusLabel = computed(() => labelFor(engineeringStatusOptions, local.engineeringStatus))
const streamLabel = computed(() =>
  labelFor([{ label: 'All', value: '' }, ...activeStreams.value], local.stream),
)
const graduationLabel = computed(() =>
  labelFor([{ label: 'All', value: '' }, ...activeGraduations.value], local.graduation),
)

// The Stream group doubles as "Engineering Branch" for engineering and
// "Graduation Stream" for graduation-level qualifications, matching how
// each context refers to it.
const streamGroupLabel = computed(() => {
  if (local.educationLevel === 'engineering') return 'Engineering Branch'
  if (local.educationLevel === 'graduation' || local.educationLevel === 'pg') return 'Graduation Stream'
  return 'Stream'
})

// ── Which dropdown (if any) is currently open ──────────────────────────────────
// Only one at a time, and the panel renders inline (normal document flow) so
// opening it pushes the filters below it down the page instead of covering them.

const openFilter = ref<string | null>(null)

function toggleFilter(name: string): void {
  openFilter.value = openFilter.value === name ? null : name
}

function handleDocumentClick(e: MouseEvent): void {
  const target = e.target as HTMLElement
  if (!target.closest('.filter-dropdown')) {
    openFilter.value = null
  }
}

onMounted(() => document.addEventListener('click', handleDocumentClick))
onBeforeUnmount(() => document.removeEventListener('click', handleDocumentClick))

// ── When filters change, reset dependent dropdowns ────────────────────────────

function onExamLevelChange(): void {
  local.jobType = ''     // reset job type when exam level changes
  local.jobCategory = '' // reset job category too
}

function onJobTypeChange(): void {
  local.jobCategory = '' // reset job category when job type changes
}

function onEducationLevelChange(): void {
  local.stream = ''             // reset stream when education level changes
  local.graduation = ''         // reset graduation when education level changes
  local.engineeringStatus = ''  // reset engineering status when education level changes
}

function onGraduationChange(): void {
  local.stream = '' // reset stream when graduation changes — Stream now depends on Graduation
}

// ── Option selection — behaves like a single-select, closes after choosing ────

function selectExamLevel(value: string): void {
  local.examLevel = value
  onExamLevelChange()
  openFilter.value = null
}

function selectJobType(value: string): void {
  local.jobType = value
  onJobTypeChange()
  openFilter.value = null
}

function selectJobCategory(value: string): void {
  local.jobCategory = value
  openFilter.value = null
}

function selectEducationLevel(value: string): void {
  local.educationLevel = value
  onEducationLevelChange()
  openFilter.value = null
}

function selectStream(value: string): void {
  local.stream = value
  openFilter.value = null
}

function selectGraduation(value: string): void {
  local.graduation = value
  onGraduationChange()
  openFilter.value = null
}

function selectEngineeringStatus(value: string): void {
  local.engineeringStatus = value
  openFilter.value = null
}

// ── Emit & reset ──────────────────────────────────────────────────────────────

function emitChange(): void {
  emit('change', {
    exam_category:     local.examLevel,
    exam_year:         '',
    stream:            local.stream,
    graduation:        local.graduation,
    educationLevel:    local.educationLevel,
    jobType:           local.jobType,
    jobCategory:       local.jobCategory,
    engineeringStatus: local.engineeringStatus,
  } as ExamFilters)
}

/** Bound to the "Apply Filters" button specifically — separate from
 *  emitChange() so the parent can react (e.g. scroll to results) only on
 *  an explicit user click, not on mount or Reset. */
function applyFilters(): void {
  emitChange()
  emit('apply')
}

function resetFilters(): void {
  Object.assign(local, defaultState())
  openFilter.value = null
  emitChange()
}

emitChange()

defineExpose({ reset: resetFilters })
</script>

<style scoped>
.filters-panel {
  position: sticky;
  top: 96px;
  max-height: calc(100vh - 96px - 24px); /* viewport minus top offset and some breathing room */
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.filter-scroll-area {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  padding-right: 2px; /* prevent scrollbar overlap */
  /* Thin, subtle scrollbar */
  scrollbar-width: thin;
  scrollbar-color: #d1d5db transparent;
}

.filter-scroll-area::-webkit-scrollbar {
  width: 4px;
}

.filter-scroll-area::-webkit-scrollbar-track {
  background: transparent;
}

.filter-scroll-area::-webkit-scrollbar-thumb {
  background-color: #d1d5db;
  border-radius: 4px;
}

.filter-actions {
  display: grid;
  grid-template-columns: 1fr 1.4fr;
  gap: 10px;
  margin-top: 8px;
  flex-shrink: 0; /* never squish — always visible at the bottom */
  padding-top: 8px;
  border-top: 1px solid #f3f4f6;
  background: inherit; /* match panel background */
}

.reset-btn {
  background: #fff;
  border: 1px solid #ddd;
  color: #1e2536;
  font-weight: 700;
  font-size: 13px;
  padding: 10px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s, border-color 0.15s;
}

.reset-btn:hover {
  background: #f3f4f6;
  border-color: #9ca3af;
}

.apply-btn {
  background: #7c3aed;
  border: none;
  color: #fff;
  font-weight: 700;
  font-size: 13px;
  padding: 10px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s;
}

.apply-btn:hover {
  background: #6d28d9;
}

/* ── Custom checkbox dropdown ─────────────────────────────────────────────────
   Renders as a normal block in the document flow (not position: absolute),
   so opening one dropdown pushes the filter groups below it further down
   the page instead of floating over and hiding them. */

.filter-dropdown-trigger {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 10px 12px;
  font-size: 13.5px;
  color: #1e2536;
  cursor: pointer;
  text-align: left;
  transition: border-color 0.15s, box-shadow 0.15s;
}

.filter-dropdown-trigger:hover {
  border-color: #a78bfa;
}

.filter-dropdown--open .filter-dropdown-trigger {
  border-color: #7c3aed;
  box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.12);
}

.filter-dropdown-chevron {
  width: 14px;
  height: 14px;
  color: #6b7280;
  flex-shrink: 0;
  transition: transform 0.15s, color 0.15s;
}

.filter-dropdown-chevron--open {
  transform: rotate(180deg);
  color: #7c3aed;
}

.filter-dropdown-panel {
  margin-top: 6px;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  background: #fff;
  padding: 6px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  max-height: 230px;
  overflow-y: auto;
}

.filter-checkbox-row {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 8px;
  border-radius: 6px;
  font-size: 13.5px;
  color: #374151;
  cursor: pointer;
  transition: background 0.12s;
}

.filter-checkbox-row:hover {
  background: #f5f3ff;
}

.filter-checkbox {
  width: 16px;
  height: 16px;
  accent-color: #7c3aed;
  cursor: pointer;
  flex-shrink: 0;
}
</style>