<template>
  <div class="exam-page">
    <div class="exam-page-grid">
      <Sidebar ref="sidebarRef" @change="onFilterChange" @apply="scrollToFilteredResults" />

      <div class="exam-page-main">

        <!-- Search for Exams -->
        <div class="search-section">
          <h3 class="section-heading">Search for Exams</h3>
          <p class="section-sub">Can't find your exam? Search here</p>
          <div class="search-bar">
            <svg class="search-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input
              v-model="searchQuery"
              type="text"
              placeholder="Search exams (e.g., JEE, NEET, UPSC, GATE, CLAT...)"
              class="search-input"
            />
          </div>
        </div>

        <!-- Search Results — appears while the search box has a query -->
        <div class="filtered-results-section" v-if="hasSearchQuery">
          <div class="filtered-results-header">
            <div>
              <h3 class="section-heading">🔍 Search Results</h3>
              <p class="section-sub">
                {{ searchResultExams.length }}
                exam{{ searchResultExams.length === 1 ? '' : 's' }} match "{{ searchQuery }}"
              </p>
            </div>
            <button class="view-all-btn" @click="clearSearch">Clear Search</button>
          </div>

          <div class="popular-grid" v-if="searchResultExams.length">
            <div
              v-for="exam in searchResultExams"
              :key="exam.id"
              class="popular-card"
              @click="goToExam(exam.id)"
            >
              <div class="popular-icon">
                <img
                  :src="exam.logo"
                  :alt="exam.label"
                  class="popular-icon-img"
                  loading="lazy"
                  @error="onLogoError"
                />
              </div>
              <h4 class="popular-name">{{ exam.label }}</h4>
              <p class="popular-desc">{{ exam.description }}</p>
              <span class="popular-count">{{ exam.testCount }} Tests</span>
            </div>
          </div>
          <div v-else class="no-results">
            No exams found for "{{ searchQuery }}"
          </div>
        </div>

        <!-- Filtered Results — appears once Apply Filters is clicked with at least one filter set -->
        <div class="filtered-results-section" ref="filteredResultsRef" v-if="hasAppliedFilters">
          <div class="filtered-results-header">
            <div>
              <h3 class="section-heading">🔎 Filtered Results</h3>
              <p class="section-sub">
                {{ filteredResultExams.length }}
                exam{{ filteredResultExams.length === 1 ? '' : 's' }} match your filters
              </p>
            </div>
            <button class="view-all-btn" @click="clearAppliedFilters">Clear Filters</button>
          </div>

          <div class="applied-filter-chips">
            <span v-if="examLevelChipLabel" class="filter-chip">Exam Type: {{ examLevelChipLabel }}</span>
            <span v-if="jobTypeChipLabel" class="filter-chip">Job Type: {{ jobTypeChipLabel }}</span>
            <span v-if="jobCategoryChipLabel" class="filter-chip">Category: {{ jobCategoryChipLabel }}</span>
            <span v-if="educationLevelChipLabel" class="filter-chip">Qualification: {{ educationLevelChipLabel }}</span>
            <span v-if="appliedFilters?.graduation" class="filter-chip">Graduation: {{ appliedFilters.graduation }}</span>
            <span v-if="appliedFilters?.engineeringStatus" class="filter-chip">Engineering Status: {{ appliedFilters.engineeringStatus }}</span>
            <span v-if="appliedFilters?.stream" class="filter-chip">Stream: {{ appliedFilters.stream }}</span>
          </div>

          <div class="popular-grid" v-if="filteredResultExams.length">
            <div
              v-for="exam in filteredResultExams"
              :key="exam.id"
              class="popular-card"
              @click="goToExam(exam.id)"
            >
              <div class="popular-icon">
                <img
                  :src="exam.logo"
                  :alt="exam.label"
                  class="popular-icon-img"
                  loading="lazy"
                  @error="onLogoError"
                />
              </div>
              <h4 class="popular-name">{{ exam.label }}</h4>
              <p class="popular-desc">{{ exam.description }}</p>
              <span class="popular-count">{{ exam.testCount }} Tests</span>
            </div>
          </div>
          <div v-else class="no-results">
            No exams match the selected filters. Try adjusting them.
          </div>
        </div>

        <!-- Popular Exams -->
        <div class="popular-section">

          <!-- Exam Category Switch Tabs -->
          <div class="category-tabs-card">
            <h4 class="category-tabs-label">Filter by Exam Type</h4>
            <div class="category-tabs-row">
              <button
                v-for="tab in EXAM_TABS"
                :key="tab.value"
                type="button"
                class="category-tab-pill"
                :class="{ 'category-tab-pill--active': activeExamTab === tab.value }"
                @click="onExamTabSelect(tab.value)"
              >
                {{ tab.label }}
              </button>
            </div>
          </div>

          <!-- Header row -->
          <div class="popular-header">
            <div>
              <h3 class="section-heading" v-if="activeExamTab === 'all'">
                📚 All Exams
              </h3>
              <h3 class="section-heading" v-else>
                {{ EXAM_TABS.find(t => t.value === activeExamTab)?.icon }}
                {{ EXAM_TABS.find(t => t.value === activeExamTab)?.label }}s
              </h3>
              <p class="section-sub" v-if="activeExamTab === 'all'">
                Explore exams across every category
              </p>
              <p class="section-sub" v-else>
                Explore top exams and start your preparation
              </p>
            </div>
            <button
              v-if="activeExamTab !== 'all'"
              class="view-all-btn"
              @click="toggleCategoryExpanded(activeExamTab)"
            >
              {{ isCategoryExpanded(activeExamTab) ? 'Show Less' : 'View All Exams' }}
            </button>
          </div>

          <!-- All Exams: grouped by category, each with its own View All button -->
          <template v-if="activeExamTab === 'all'">
            <div
              v-for="group in groupedExamsByCategory"
              :key="group.category"
              class="category-group"
            >
              <div class="category-group-header">
                <h4 class="category-group-title">{{ group.icon }} {{ group.label }}</h4>
                <button
                  class="view-all-btn view-all-btn--small"
                  @click="toggleCategoryExpanded(group.category)"
                >
                  {{ isCategoryExpanded(group.category) ? 'Show Less' : 'View All' }}
                </button>
              </div>
              <div class="popular-grid">
                <div
                  v-for="exam in group.exams"
                  :key="exam.id"
                  class="popular-card"
                  @click="goToExam(exam.id)"
                >
                  <div class="popular-icon">
                    <img
                      :src="exam.logo"
                      :alt="exam.label"
                      class="popular-icon-img"
                      loading="lazy"
                      @error="onLogoError"
                    />
                  </div>
                  <h4 class="popular-name">{{ exam.label }}</h4>
                  <p class="popular-desc">{{ exam.description }}</p>
                  <span class="popular-count">{{ exam.testCount }} Tests</span>
                </div>
              </div>
            </div>

            <div v-if="groupedExamsByCategory.length === 0" class="no-results">
              No exams found for "{{ searchQuery }}"
            </div>
          </template>

          <!-- Single category view -->
          <template v-else>
            <div class="popular-grid">
              <div
                v-for="exam in filteredPopularExams"
                :key="exam.id"
                class="popular-card"
                @click="goToExam(exam.id)"
              >
                <div class="popular-icon">
                  <img
                    :src="exam.logo"
                    :alt="exam.label"
                    class="popular-icon-img"
                    loading="lazy"
                    @error="onLogoError"
                  />
                </div>
                <h4 class="popular-name">{{ exam.label }}</h4>
                <p class="popular-desc">{{ exam.description }}</p>
                <span class="popular-count">{{ exam.testCount }} Tests</span>
              </div>
            </div>

            <div v-if="filteredPopularExams.length === 0" class="no-results">
              No exams found for "{{ searchQuery }}"
            </div>
          </template>
        </div>

        <!-- Upcoming Exams -->
        <TestGrid
          :exams="pagedExams"
          :loading="loading"
          :current-page="currentPage"
          :total-pages="totalPages"
          @page-change="onPageChange"
          @take="onTakeTest"
          @bookmark="onBookmark"
        />
      </div>

      <FeaturedAds />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick, type Ref } from 'vue'
import { useRouter } from 'vue-router'
import api from '@/services/axiosInstance'
import Sidebar from '../components/exam/Sidebar.vue'
import TestGrid from '../components/exam/TestGrid.vue'
import FeaturedAds from '../components/exam/FeaturedAds.vue'
import type { Exam, ExamFilters, PaginatedResponse } from '@/types/exam'
import { usePracticeTestStore } from '../stores/practiceTest'

// Scraped from https://www.ixambee.com/free-mock-tests
// Shape: { "<category heading>": [{ name: string, logo: string }] }
import mockCategoriesRaw from '@/data/mocktest_categories.json'

const router = useRouter()
const store = usePracticeTestStore()
const searchQuery = ref('')

// ── Exam category tabs ────────────────────────────────────────────────────────
const EXAM_TABS = [
  { label: 'All Exams',     value: 'all',      icon: '📚' },
  { label: 'Entrance Exam', value: 'entrance', icon: '🎓' },
  { label: 'Job Exam',      value: 'job',      icon: '💼' },
  { label: 'School Exam',   value: 'school',   icon: '🏫' },
]
const activeExamTab = ref<'all' | 'entrance' | 'job' | 'school'>('entrance')

function onExamTabSelect(value: typeof activeExamTab.value): void {
  activeExamTab.value = value
}

// ── All popular exams by category ─────────────────────────────────────────────

interface PopularExam {
  id: string
  label: string
  logo: string
  colorClass: string
  description: string
  testCount: string
  category: 'entrance' | 'job' | 'school'
  // Filter metadata — used by filteredResultExams
  educationLevels?: string[]   // e.g. ['12th', 'engineering']
  streams?: string[]           // e.g. ['science', 'cse']
  graduations?: string[]       // e.g. ['ug', 'pg']
  jobTypes?: string[]          // e.g. ['government', 'it']
  jobCategories?: string[]     // e.g. ['banking', 'railways', 'defence']
  engineeringStatuses?: string[] // e.g. ['graduated', 'pursuing'] — only meaningful for engineering exams
}

const popularExams: PopularExam[] = [
  // ── ENTRANCE EXAMS ────────────────────────────────────────────────────────
  // National
  {
    id: 'jee_main',
    label: 'JEE Main',
    logo: 'https://cbseportal.com/files/IIT-JEE-LOGO.jpg',
    colorClass: 'ico-purple',
    description: 'Engineering Entrance (National)',
    testCount: '12.5K+',
    category: 'entrance',
    educationLevels: ['12th', 'engineering'],
    streams: ['science', 'cse', 'mechanical', 'civil', 'electrical', 'ece', 'it', 'chemical', 'aerospace'],
    graduations: ['ug'],
  },
  {
    id: 'jee_advanced',
    label: 'JEE Advanced',
    logo: 'https://cbseportal.com/files/IIT-JEE-LOGO.jpg',
    colorClass: 'ico-indigo',
    description: 'IIT Admission Exam',
    testCount: '8K+',
    category: 'entrance',
    educationLevels: ['12th', 'engineering'],
    streams: ['science', 'cse', 'mechanical', 'civil', 'electrical', 'ece', 'it', 'chemical', 'aerospace'],
    graduations: ['ug'],
  },
  {
    id: 'neet_ug',
    label: 'NEET-UG',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYPCJURAY71Yy3R1Qx-grHgv2Dd5GHsazZK8ChrrNTIuVUyRwQlL3yyQuL&s=10',
    colorClass: 'ico-green',
    description: 'Medical Entrance (UG)',
    testCount: '8.2K+',
    category: 'entrance',
    educationLevels: ['12th'],
    streams: ['science'],
    graduations: ['ug'],
  },
  {
    id: 'cuet_ug',
    label: 'CUET-UG',
    logo: 'https://www.cucetexam.in/wp-content/uploads/2025/10/gggggggg.jpg',
    colorClass: 'ico-teal',
    description: 'Central University Admissions UG',
    testCount: '5.9K+',
    category: 'entrance',
    educationLevels: ['12th'],
    streams: ['science', 'commerce', 'arts'],
    graduations: ['ug'],
  },
  {
    id: 'clat',
    label: 'CLAT',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2vZlNAa_8ju5467-TqlgtRJpWV32jqn8351wc1Mez02EKOcTn9a2jw7ZZ&s=10',
    colorClass: 'ico-yellow',
    description: 'Law Entrance Exam',
    testCount: '3.2K+',
    category: 'entrance',
    educationLevels: ['12th', 'graduation'],
    streams: ['science', 'commerce', 'arts', 'ba', 'bsc', 'bcom', 'llb'],
    graduations: ['ug', 'pg'],
  },
  {
    id: 'nata',
    label: 'NATA',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-orange',
    description: 'Architecture Aptitude Test',
    testCount: '1.8K+',
    category: 'entrance',
    educationLevels: ['12th'],
    streams: ['science', 'commerce', 'arts'],
    graduations: ['ug'],
  },
  {
    id: 'bitsat',
    label: 'BITSAT',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-blue',
    description: 'BITS Pilani Admission Test',
    testCount: '2.1K+',
    category: 'entrance',
    educationLevels: ['12th'],
    streams: ['science'],
    graduations: ['ug'],
  },
  {
    id: 'viteee',
    label: 'VITEEE',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-red',
    description: 'VIT Engineering Entrance',
    testCount: '1.5K+',
    category: 'entrance',
    educationLevels: ['12th'],
    streams: ['science'],
    graduations: ['ug'],
  },
  {
    id: 'srmjeee',
    label: 'SRMJEEE',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-cyan',
    description: 'SRM Joint Engineering Entrance',
    testCount: '1.2K+',
    category: 'entrance',
    educationLevels: ['12th'],
    streams: ['science'],
    graduations: ['ug'],
  },
  {
    id: 'iat',
    label: 'IAT',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-violet',
    description: 'IISER Aptitude Test',
    testCount: '0.9K+',
    category: 'entrance',
    educationLevels: ['12th'],
    streams: ['science'],
    graduations: ['ug'],
  },
  {
    id: 'cat',
    label: 'CAT',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLJemUdN-tcSUYlJVAE_39qYQsXmnoTab8d-RNN9rQRCaRE2BA1ZTLGsQ&s=10',
    colorClass: 'ico-red',
    description: 'MBA Admissions (IIMs)',
    testCount: '5.4K+',
    category: 'entrance',
    educationLevels: ['graduation', 'engineering'],
    streams: ['ba', 'bsc', 'bcom', 'bba', 'bca', 'btech', 'cse', 'mechanical', 'civil', 'electrical', 'ece', 'it'],
    graduations: ['ug'],
  },
  {
    id: 'gate',
    label: 'GATE',
    logo: 'https://www.spinoneducation.com/wp-content/uploads/2022/02/Gate.webp',
    colorClass: 'ico-indigo',
    description: 'PG Engineering & PSU Jobs',
    testCount: '6.1K+',
    category: 'entrance',
    educationLevels: ['engineering', 'graduation'],
    streams: ['cse', 'mechanical', 'civil', 'electrical', 'ece', 'it', 'chemical', 'aerospace', 'btech'],
    graduations: ['ug', 'pg'],
    engineeringStatuses: ['graduated', 'pursuing'],
  },
  {
    id: 'isro_scientist',
    label: 'ISRO Scientist/Engineer',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/1/13/ISRO_Logo.svg',
    colorClass: 'ico-indigo',
    description: 'PSU / Government Engineering Jobs',
    testCount: '900+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['psu'],
    educationLevels: ['engineering'],
    streams: ['cse', 'mechanical', 'civil', 'electrical', 'ece', 'it', 'aerospace'],
    graduations: ['ug'],
    engineeringStatuses: ['graduated'],
  },
  {
    id: 'drdo_scientist_b',
    label: 'DRDO Scientist B',
    logo: 'https://upload.wikimedia.org/wikipedia/en/6/6f/Official_logo_of_DRDO.png',
    colorClass: 'ico-indigo',
    description: 'PSU / Government Engineering Jobs',
    testCount: '700+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['psu', 'defence'],
    educationLevels: ['engineering'],
    streams: ['cse', 'mechanical', 'civil', 'electrical', 'ece', 'it'],
    graduations: ['ug'],
    engineeringStatuses: ['graduated'],
  },
  {
    id: 'bel_probationary_engineer',
    label: 'BEL Probationary Engineer',
    logo: 'https://upload.wikimedia.org/wikipedia/en/2/2e/Bharat_Electronics_Limited_Logo.svg',
    colorClass: 'ico-indigo',
    description: 'PSU / Government Engineering Jobs',
    testCount: '450+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['psu'],
    educationLevels: ['engineering'],
    streams: ['cse', 'electronics', 'electrical', 'ece', 'it'],
    graduations: ['ug'],
    engineeringStatuses: ['graduated'],
  },
  {
    id: 'nic_scientist_b',
    label: 'NIC Scientist B',
    logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/e3/National_Informatics_Centre_Logo.png/200px-National_Informatics_Centre_Logo.png',
    colorClass: 'ico-indigo',
    description: 'PSU / Government Engineering Jobs',
    testCount: '300+',
    category: 'job',
    jobTypes: ['government', 'it'],
    jobCategories: ['psu'],
    educationLevels: ['engineering'],
    streams: ['cse', 'it'],
    graduations: ['ug'],
    engineeringStatuses: ['graduated'],
  },
  {
    id: 'gail_executive_trainee',
    label: 'GAIL Executive Trainee',
    logo: 'https://upload.wikimedia.org/wikipedia/en/9/9a/GAIL_%28India%29_Limited_logo.svg',
    colorClass: 'ico-indigo',
    description: 'PSU / Government Engineering Jobs',
    testCount: '350+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['psu'],
    educationLevels: ['engineering'],
    streams: ['cse', 'mechanical', 'civil', 'electrical', 'chemical'],
    graduations: ['ug'],
    engineeringStatuses: ['graduated'],
  },
  {
    id: 'bhel_engineer_trainee',
    label: 'BHEL Engineer Trainee',
    logo: 'https://upload.wikimedia.org/wikipedia/en/0/0c/Bharat_Heavy_Electricals_Limited_logo.svg',
    colorClass: 'ico-indigo',
    description: 'PSU / Government Engineering Jobs',
    testCount: '400+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['psu'],
    educationLevels: ['engineering'],
    streams: ['cse', 'mechanical', 'civil', 'electrical', 'ece'],
    graduations: ['ug'],
    engineeringStatuses: ['graduated'],
  },
  {
    id: 'neet_pg',
    label: 'NEET-PG',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYPCJURAY71Yy3R1Qx-grHgv2Dd5GHsazZK8ChrrNTIuVUyRwQlL3yyQuL&s=10',
    colorClass: 'ico-green',
    description: 'Medical PG Entrance',
    testCount: '3.8K+',
    category: 'entrance',
    educationLevels: ['graduation'],
    streams: ['mbbs'],
    graduations: ['pg'],
  },
  // Maharashtra
  {
    id: 'mht_cet',
    label: 'MHT-CET',
    logo: 'https://upload.wikimedia.org/wikipedia/en/6/60/MHT-CET_logo.png',
    colorClass: 'ico-cyan',
    description: 'Maharashtra Engineering / Pharmacy',
    testCount: '4.6K+',
    category: 'entrance',
    educationLevels: ['12th'],
    streams: ['science'],
    graduations: ['ug'],
  },
  {
    id: 'mah_mba_cet',
    label: 'MAH MBA CET',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLJemUdN-tcSUYlJVAE_39qYQsXmnoTab8d-RNN9rQRCaRE2BA1ZTLGsQ&s=10',
    colorClass: 'ico-orange',
    description: 'Maharashtra MBA Admissions',
    testCount: '1.4K+',
    category: 'entrance',
    educationLevels: ['graduation', 'engineering'],
    streams: ['ba', 'bsc', 'bcom', 'bba', 'btech', 'cse', 'mechanical'],
    graduations: ['pg'],
  },
  {
    id: 'mah_mca_cet',
    label: 'MAH MCA CET',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-blue',
    description: 'Maharashtra MCA Admissions',
    testCount: '0.8K+',
    category: 'entrance',
    educationLevels: ['graduation'],
    streams: ['bsc', 'bca', 'bcom', 'btech'],
    graduations: ['pg'],
  },
  {
    id: 'mah_llb_cet',
    label: 'MAH LLB CET',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2vZlNAa_8ju5467-TqlgtRJpWV32jqn8351wc1Mez02EKOcTn9a2jw7ZZ&s=10',
    colorClass: 'ico-yellow',
    description: 'Maharashtra Law Admissions',
    testCount: '0.7K+',
    category: 'entrance',
    educationLevels: ['graduation'],
    streams: ['ba', 'bsc', 'bcom', 'bba'],
    graduations: ['ug', 'pg'],
  },
  {
    id: 'mah_bed_cet',
    label: 'MAH B.Ed CET',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-teal',
    description: 'Maharashtra B.Ed Admissions',
    testCount: '0.6K+',
    category: 'entrance',
    educationLevels: ['graduation'],
    streams: ['ba', 'bsc', 'bcom'],
    graduations: ['ug'],
  },

  // ── JOB EXAMS ─────────────────────────────────────────────────────────────
  // Government
  {
    id: 'upsc',
    label: 'UPSC CSE',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-orange',
    description: 'Civil Services (IAS/IPS)',
    testCount: '15K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['civil_services'],
    educationLevels: ['graduation', 'engineering', 'pg'],
    streams: ['ba', 'bsc', 'bcom', 'bba', 'btech', 'cse', 'mechanical', 'civil', 'mtech', 'msc', 'ma'],
    graduations: ['ug', 'pg'],
  },
  {
    id: 'ssc_cgl',
    label: 'SSC CGL',
    logo: 'https://www.ssccoachingchandigarh.in/assets/upload/course/SSC_CGL_Logo1.png',
    colorClass: 'ico-pink',
    description: 'Staff Selection Commission',
    testCount: '9.1K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['ssc'],
    educationLevels: ['graduation', 'engineering'],
    streams: ['ba', 'bsc', 'bcom', 'bba', 'btech', 'cse', 'mechanical', 'civil'],
    graduations: ['ug'],
  },
  {
    id: 'ssc_chsl',
    label: 'SSC CHSL',
    logo: 'https://www.ssccoachingchandigarh.in/assets/upload/course/SSC_CGL_Logo1.png',
    colorClass: 'ico-pink',
    description: 'Higher Secondary Level Exam',
    testCount: '5.2K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['ssc'],
    educationLevels: ['12th'],
    streams: ['science', 'commerce', 'arts'],
    graduations: [],
  },
  {
    id: 'ibps_po',
    label: 'IBPS PO / Clerk',
    logo: 'https://p7.hiclipart.com/preview/385/732/834/ibps-regional-rural-banks-exam-ibps-clerk-exam-ibps-probationary-officers-exam-%C2%B7-2017-ibps-probationary-officers-exam-%C2%B7-2018-ibps-specialist-officers-exam-credit-card-mock-thumbnail.jpg',
    colorClass: 'ico-blue',
    description: 'Bank PO & Clerk Recruitment',
    testCount: '7.3K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['banking'],
    educationLevels: ['graduation', 'engineering'],
    streams: ['ba', 'bsc', 'bcom', 'bba', 'btech', 'cse'],
    graduations: ['ug'],
  },
  {
    id: 'sbi_po',
    label: 'SBI PO / Clerk',
    logo: 'https://p7.hiclipart.com/preview/385/732/834/ibps-regional-rural-banks-exam-ibps-clerk-exam-ibps-probationary-officers-exam-%C2%B7-2017-ibps-probationary-officers-exam-%C2%B7-2018-ibps-specialist-officers-exam-credit-card-mock-thumbnail.jpg',
    colorClass: 'ico-blue',
    description: 'State Bank Recruitment',
    testCount: '6.8K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['banking'],
    educationLevels: ['graduation', 'engineering'],
    streams: ['ba', 'bsc', 'bcom', 'bba', 'btech', 'cse'],
    graduations: ['ug'],
  },
  {
    id: 'rbi_grade_b',
    label: 'RBI Grade B',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQklYqshl7WUCmaKgo36eLWU_thdLVOKguR5co1ha3qaw&s=10',
    colorClass: 'ico-teal',
    description: 'Central Bank Officer Recruitment',
    testCount: '2.5K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['banking'],
    educationLevels: ['graduation', 'engineering', 'pg'],
    streams: ['ba', 'bsc', 'bcom', 'bba', 'btech', 'mba', 'mcom'],
    graduations: ['ug', 'pg'],
  },
  {
    id: 'rrb_ntpc',
    label: 'RRB NTPC',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgB5g3VOJIXhHS1cmq5Hx8lduotfJ3cXsGgzhDG4INGg&s=10',
    colorClass: 'ico-violet',
    description: 'Railway Recruitment Board Jobs',
    testCount: '6.1K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['railways'],
    educationLevels: ['12th', 'graduation'],
    streams: ['science', 'commerce', 'arts', 'ba', 'bsc', 'bcom'],
    graduations: ['ug'],
  },
  {
    id: 'nda',
    label: 'NDA',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/6/6e/National_Defence_Academy_NDA.png',
    colorClass: 'ico-brown',
    description: 'National Defence Academy',
    testCount: '3.5K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['defence'],
    educationLevels: ['12th'],
    streams: ['science', 'commerce', 'arts'],
    graduations: [],
  },
  {
    id: 'cds',
    label: 'CDS',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/6/6e/National_Defence_Academy_NDA.png',
    colorClass: 'ico-brown',
    description: 'Combined Defence Services',
    testCount: '2.8K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['defence'],
    educationLevels: ['graduation', 'engineering'],
    streams: ['ba', 'bsc', 'bcom', 'btech', 'cse', 'mechanical'],
    graduations: ['ug'],
  },
  {
    id: 'ugc_net',
    label: 'UGC NET',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMcwHR_BWj_ZJNehNd1spgHHYc9nx7NvXzaF3g6xtTJEos8PNcrWfDmErY&s=10',
    colorClass: 'ico-slate',
    description: 'Lectureship & Research Eligibility',
    testCount: '2.9K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['teaching'],
    educationLevels: ['pg'],
    streams: ['mtech', 'msc', 'mba', 'mca', 'ma', 'mcom'],
    graduations: ['pg'],
  },
  // IT Sector
  {
    id: 'tcs_nqt',
    label: 'TCS NQT',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-blue',
    description: 'TCS National Qualifier Test',
    testCount: '3.1K+',
    category: 'job',
    jobTypes: ['it'],
    jobCategories: ['software'],
    educationLevels: ['engineering', 'graduation'],
    streams: ['cse', 'it', 'ece', 'electrical', 'mechanical', 'btech', 'bca', 'bsc'],
    graduations: ['ug'],
  },
  {
    id: 'elitmus',
    label: 'eLitmus pH Test',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-purple',
    description: 'Campus Hiring Assessment',
    testCount: '1.6K+',
    category: 'job',
    jobTypes: ['it'],
    educationLevels: ['engineering', 'graduation'],
    streams: ['cse', 'it', 'ece', 'btech', 'bca', 'bsc'],
    graduations: ['ug'],
  },
  {
    id: 'amcat',
    label: 'AMCAT',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-green',
    description: 'Employability & IT Assessment',
    testCount: '2.2K+',
    category: 'job',
    jobTypes: ['it', 'non_it', 'private'],
    educationLevels: ['engineering', 'graduation'],
    streams: ['cse', 'it', 'ece', 'electrical', 'mechanical', 'btech', 'bca', 'bsc', 'bcom', 'bba'],
    graduations: ['ug'],
  },
  {
    id: 'wipro_elite',
    label: 'Wipro Elite NLTH',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-blue',
    description: 'Wipro Engineering Hiring Test',
    testCount: '1.4K+',
    category: 'job',
    jobTypes: ['it'],
    educationLevels: ['engineering'],
    streams: ['cse', 'it', 'ece', 'electrical', 'mechanical'],
    graduations: ['ug'],
  },
  {
    id: 'infosys_sp',
    label: 'Infosys SP / DSE',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-indigo',
    description: 'Infosys Systems Programmer Test',
    testCount: '1.3K+',
    category: 'job',
    jobTypes: ['it'],
    educationLevels: ['engineering'],
    streams: ['cse', 'it', 'ece'],
    graduations: ['ug'],
  },
  // Teacher / Education
  {
    id: 'ctet',
    label: 'CTET',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwh6nLJgy5o2Pq32H3i2WF1To_LEi4_g04SH3kKF1sHgjoUxlJEflnmy0m&s=10',
    colorClass: 'ico-orange',
    description: 'Central Teacher Eligibility Test',
    testCount: '4.2K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['teaching'],
    educationLevels: ['graduation', 'pg'],
    streams: ['ba', 'bsc', 'bcom', 'ma', 'msc'],
    graduations: ['ug', 'pg'],
  },
  {
    id: 'maha_tet',
    label: 'MAHA TET',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwh6nLJgy5o2Pq32H3i2WF1To_LEi4_g04SH3kKF1sHgjoUxlJEflnmy0m&s=10',
    colorClass: 'ico-orange',
    description: 'Maharashtra Teacher Eligibility Test',
    testCount: '2.1K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['teaching'],
    educationLevels: ['graduation', 'pg'],
    streams: ['ba', 'bsc', 'bcom', 'ma', 'msc'],
    graduations: ['ug', 'pg'],
  },
  {
    id: 'kvs',
    label: 'KVS Exam',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-teal',
    description: 'Kendriya Vidyalaya Recruitment',
    testCount: '1.8K+',
    category: 'job',
    jobTypes: ['government'],
    jobCategories: ['teaching'],
    educationLevels: ['graduation', 'pg'],
    streams: ['ba', 'bsc', 'bcom', 'ma', 'msc'],
    graduations: ['ug', 'pg'],
  },
  {
    id: 'csir_net',
    label: 'CSIR NET',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMcwHR_BWj_ZJNehNd1spgHHYc9nx7NvXzaF3g6xtTJEos8PNcrWfDmErY&s=10',
    colorClass: 'ico-slate',
    description: 'Science Research Fellowship',
    testCount: '1.5K+',
    category: 'job',
    jobTypes: ['government'],
    educationLevels: ['pg'],
    streams: ['msc'],
    graduations: ['pg'],
  },

  // ── SCHOOL EXAMS ──────────────────────────────────────────────────────────
  // Olympiads & Talent Search
  {
    id: 'ntse',
    label: 'NTSE',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-yellow',
    description: 'National Talent Search Exam',
    testCount: '2.3K+',
    category: 'school',
    educationLevels: ['10th'],
    streams: ['science', 'maths', 'social'],
  },
  {
    id: 'nso',
    label: 'NSO',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-green',
    description: 'National Science Olympiad',
    testCount: '1.9K+',
    category: 'school',
    educationLevels: ['10th', '12th'],
    streams: ['science', 'maths'],
  },
  {
    id: 'imo',
    label: 'IMO',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-blue',
    description: 'International Maths Olympiad',
    testCount: '1.7K+',
    category: 'school',
    educationLevels: ['10th', '12th'],
    streams: ['maths', 'science'],
  },
  {
    id: 'ieo',
    label: 'IEO',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-purple',
    description: 'International English Olympiad',
    testCount: '1.2K+',
    category: 'school',
    educationLevels: ['10th', '12th'],
    streams: ['science', 'commerce', 'arts', 'social'],
  },
  {
    id: 'nco',
    label: 'NCO',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-cyan',
    description: 'National Cyber Olympiad',
    testCount: '1.0K+',
    category: 'school',
    educationLevels: ['10th', '12th'],
    streams: ['science', 'maths'],
  },
  {
    id: 'rmo',
    label: 'RMO',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-red',
    description: 'Regional Maths Olympiad',
    testCount: '0.8K+',
    category: 'school',
    educationLevels: ['10th', '12th'],
    streams: ['maths', 'science'],
  },
  {
    id: 'ino',
    label: 'INO',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-indigo',
    description: 'Indian National Olympiad',
    testCount: '0.7K+',
    category: 'school',
    educationLevels: ['10th', '12th'],
    streams: ['science', 'maths'],
  },
  // Scholarship
  {
    id: 'nmms',
    label: 'NMMS',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-orange',
    description: 'National Means Cum Merit Scholarship',
    testCount: '1.4K+',
    category: 'school',
    educationLevels: ['10th'],
    streams: ['science', 'maths', 'social'],
  },
  {
    id: 'pm_yasasvi',
    label: 'PM YASASVI',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-teal',
    description: 'OBC / EBC Scholarship Exam',
    testCount: '0.9K+',
    category: 'school',
    educationLevels: ['10th'],
    streams: ['science', 'maths', 'social'],
  },
  {
    id: 'msce_scholarship',
    label: 'MSCE Scholarship',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-pink',
    description: 'Maharashtra State Scholarship Test',
    testCount: '0.8K+',
    category: 'school',
    educationLevels: ['10th'],
    streams: ['science', 'maths', 'social'],
  },
  // School Admissions
  {
    id: 'jnvst',
    label: 'JNVST',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-violet',
    description: 'Navodaya Vidyalaya Selection Test',
    testCount: '1.1K+',
    category: 'school',
    educationLevels: ['10th'],
    streams: ['science', 'maths', 'social'],
  },
  {
    id: 'aissee',
    label: 'AISSEE',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAKwL6ZLBje364p9t7MyfVGNX0Nky7zvXEPX1dbOWV1W8OKcxSDRTB5-Le&s=10',
    colorClass: 'ico-brown',
    description: 'Sainik School Entrance Exam',
    testCount: '0.9K+',
    category: 'school',
    educationLevels: ['10th'],
    streams: ['science', 'maths', 'social'],
  },
]

const POPULAR_LIMIT = 6

/** Tracks which categories ('entrance' | 'job' | 'school') currently have
 *  their "View All" expanded, so each category's button only affects its
 *  own grid — not the others. */
const expandedCategories = ref<Set<string>>(new Set())

function isCategoryExpanded(cat: string): boolean {
  return expandedCategories.value.has(cat)
}

function toggleCategoryExpanded(cat: string): void {
  const next = new Set(expandedCategories.value)
  if (next.has(cat)) {
    next.delete(cat)
  } else {
    next.add(cat)
  }
  expandedCategories.value = next
}

const filteredPopularExams = computed(() => {
  const query = searchQuery.value.trim().toLowerCase()
  let list = popularExams.filter(e => e.category === activeExamTab.value)
  if (query) {
    list = list.filter(e =>
      e.label.toLowerCase().includes(query) ||
      e.description.toLowerCase().includes(query)
    )
  }
  return isCategoryExpanded(activeExamTab.value) ? list : list.slice(0, POPULAR_LIMIT)
})

/** Used when the "All Exams" option is selected — buckets every exam
 *  back into its category (entrance / job / school) so they can be
 *  rendered as separate labelled sections, each with its own
 *  independent "View All" button. */
const groupedExamsByCategory = computed(() => {
  const query = searchQuery.value.trim().toLowerCase()
  const categories: Array<'entrance' | 'job' | 'school'> = ['entrance', 'job', 'school']

  return categories
    .map(cat => {
      let list = popularExams.filter(e => e.category === cat)
      if (query) {
        list = list.filter(e =>
          e.label.toLowerCase().includes(query) ||
          e.description.toLowerCase().includes(query)
        )
      }
      const tab = EXAM_TABS.find(t => t.value === cat)
      return {
        category: cat,
        label: `${tab?.label ?? cat}s`,
        icon: tab?.icon ?? '',
        exams: isCategoryExpanded(cat) ? list : list.slice(0, POPULAR_LIMIT),
      }
    })
    .filter(group => group.exams.length > 0)
})

/** If a logo URL fails to load (e.g. Wikimedia hotlink blocked/broken), hide the <img>
 *  so the colored circle background shows instead of a broken-image icon. */
function onLogoError(event: Event): void {
  const target = event.target as HTMLImageElement
  target.style.display = 'none'
}

// Maps each exam slug to its exam_category string (used by the store /
// downstream API calls). Update values here if your DB uses different strings.
const EXAM_CATEGORY_MAP: Record<string, string> = {
  // ── Entrance ───────────────────────────────────────────────────────────────
  jee_main:         'Engineering Entrance Exam',
  jee_advanced:     'Engineering Entrance Exam',
  neet_ug:          'Medical Entrance Exam',
  cuet_ug:          'Central University Entrance Exam',
  clat:             'Law Entrance Exam',
  nata:             'Architecture Entrance Exam',
  bitsat:           'Engineering Entrance Exam',
  viteee:           'Engineering Entrance Exam',
  srmjeee:          'Engineering Entrance Exam',
  iat:              'Science Entrance Exam',
  cat:              'Management Entrance Exam',
  gate:             'Engineering PG Entrance Exam',
  neet_pg:          'Medical PG Entrance Exam',
  mht_cet:          'State Engineering Entrance Exam',
  mah_mba_cet:      'State MBA Entrance Exam',
  mah_mca_cet:      'State MCA Entrance Exam',
  mah_llb_cet:      'State Law Entrance Exam',
  mah_bed_cet:      'State BEd Entrance Exam',
  // ── Job ────────────────────────────────────────────────────────────────────
  upsc:             'Civil Services Exam',
  ssc_cgl:          'Staff Selection Exam',
  ssc_chsl:         'Staff Selection Exam',
  ibps_po:          'Banking Exam',
  sbi_po:           'Banking Exam',
  rbi_grade_b:      'Banking Exam',
  rrb_ntpc:         'Railway Recruitment Exam',
  nda:              'Defence Entrance Exam',
  cds:              'Defence Entrance Exam',
  ugc_net:          'Teaching Eligibility Exam',
  tcs_nqt:          'IT Hiring Exam',
  elitmus:          'IT Hiring Exam',
  amcat:            'IT Hiring Exam',
  wipro_elite:      'IT Hiring Exam',
  infosys_sp:       'IT Hiring Exam',
  ctet:             'Teaching Eligibility Exam',
  maha_tet:         'Teaching Eligibility Exam',
  kvs:              'Teaching Recruitment Exam',
  csir_net:         'Research Eligibility Exam',
  // ── School ─────────────────────────────────────────────────────────────────
  ntse:             'Scholarship Exam',
  nso:              'Olympiad Exam',
  imo:              'Olympiad Exam',
  ieo:              'Olympiad Exam',
  nco:              'Olympiad Exam',
  rmo:              'Olympiad Exam',
  ino:              'Olympiad Exam',
  nmms:             'Scholarship Exam',
  pm_yasasvi:       'Scholarship Exam',
  msce_scholarship: 'State Scholarship Exam',
  jnvst:            'School Admission Exam',
  aissee:           'School Admission Exam',
}

async function goToExam(examId: string): Promise<void> {
  const exam = popularExams.find(e => e.id === examId)
  if (!exam) return

  const category = EXAM_CATEGORY_MAP[exam.id] ?? exam.label

  // Store the selected exam so downstream views (test-type, subject, topic) can use it.
  store.setExam({
    id: exam.id,
    label: exam.label,
    category,
  })

  // Resolve the REAL backend Exam row (numeric exam_id) before navigating.
  // Previously this set examType.id to the cosmetic UI slug (e.g. 'jee_main',
  // 'gate'), which is never a real PK or exam_code — every downstream view
  // (SelectSubjectView, Createcustomtestview, TestAttemptView) checks
  // /^\d+$/.test(examType.id) and silently falls back to weaker matching
  // when it isn't numeric, which is why subjects/chapters came back empty.
  try {
    const res = await api.get('/exams/', { params: { exam_category: category } })
    const rows: { exam_id: number; exam_code: string; exam_name: string }[] = res.data.results ?? []

    // Try an exact exam_code match first (e.g. 'jee_main' -> 'JEE_MAIN').
    const wantedCode = exam.id.toUpperCase()
    const match =
      rows.find(r => r.exam_code.trim().toUpperCase() === wantedCode) ??
      // If the category only maps to one real exam, that's an unambiguous match too.
      (rows.length === 1 ? rows[0] : null)

    if (match) {
      store.setExamType({ id: String(match.exam_id), dbId: match.exam_id, label: match.exam_name })
      router.push({ name: 'practice-test-type' })
      return
    }
  } catch {
    // Network/API error — fall through to the disambiguation screen below
    // rather than sending the user forward with a broken examType.
  }

  // Couldn't confidently resolve a single real exam — this category covers
  // more than one exam type (e.g. GATE has CS/ECE/ME, UPSC has Prelims/Mains)
  // or the lookup failed. Send the user to the exam-type picker to choose
  // the specific exam explicitly, instead of guessing and breaking later.
  router.push({ name: 'practice-exam-type' })
}

// ── Upcoming Exams (fed from the scraped ixambee JSON) ──────

/** Extra field beyond the base Exam type — TestGrid can ignore it if unused. */
type ScrapedExam = Exam & { logo?: string | null }

interface RawCategoryEntry {
  name: string
  logo: string | null
}

/**
 * Best-effort category bucket, purely from the exam's name, so it lines up
 * with the exam_category values used elsewhere in this file (BANKING, SSC,
 * RAILWAY, etc.). Adjust the keyword lists as needed for your data.
 */
function guessCategory(name: string): string {
  const n = name.toUpperCase()
  if (/\b(IBPS|SBI|BANK|RBI|NABARD|IDBI|RRB\s*(PO|CLERK|OFFICER)|FEDERAL BANK|CANARA|SYNDICATE)\b/.test(n)) return 'BANKING'
  if (/\bSSC\b/.test(n)) return 'SSC'
  if (/\b(RAILWAY|RRB\s*(NTPC|JE|GROUP)|RPF)\b/.test(n)) return 'RAILWAY'
  if (/\b(NIACL|LIC|OICL|GIC|INSURANCE|ECGC)\b/.test(n)) return 'INSURANCE'
  if (/\b(SEBI|PFRDA|EPFO)\b/.test(n)) return 'REGULATORY'
  if (/\b(POLICE|ARMY|NAVY|AIR ?FORCE|CONSTABLE|AGNIVEER|AFCAT)\b/.test(n)) return 'DEFENCE'
  if (/\b(KVS|NVS|TEACHER|TET|EMRS)\b/.test(n)) return 'TEACHING'
  if (/\bUPSC\b/.test(n)) return 'UPSC'
  if (/\b(MAT|CMAT|CLAT)\b/.test(n)) return 'MBA_LAW'
  return 'OTHER'
}

/** Flatten { "<category heading>": [...] } into a single list of raw entries. */
function flattenRawCategories(raw: Record<string, RawCategoryEntry[]>): RawCategoryEntry[] {
  return Object.values(raw).flat()
}

/** Map one scraped { name, logo } entry to the Exam shape TestGrid expects. */
function mapToExam(entry: RawCategoryEntry, index: number): ScrapedExam {
  return {
    exam_id: index + 1,
    exam_name: entry.name,
    exam_year: new Date().getFullYear(),
    conducting_body: entry.name.split(' ')[0], // e.g. "SBI", "IBPS", "SSC" — refine if you need something smarter
    exam_category: guessCategory(entry.name),
    question_count: 0,          // not available from the scrape — TestGrid should treat 0/blank as "not shown"
    duration_minutes: 0,        // not available from the scrape
    difficulty: 'medium',
    language: 'English, Hindi',
    logo: entry.logo,
  }
}

const allScrapedExams: ScrapedExam[] = flattenRawCategories(
  mockCategoriesRaw as unknown as Record<string, RawCategoryEntry[]>
).map(mapToExam)

const exams: Ref<Exam[]> = ref([])
const loading: Ref<boolean> = ref(false)
const currentPage: Ref<number> = ref(1)

/** "Upcoming Exams" is now a short preview, not a paginated browse-all list —
 *  cap it to a handful of exams. totalPages stays at 1 so TestGrid's
 *  pagination controls (which only render when totalPages > 1) stay hidden. */
const UPCOMING_EXAMS_LIMIT = 6
const totalPages = computed(() => 1)

/** Local dataset filtered by the search box only.
 *  NOTE: intentionally NOT filtered by the sidebar's Apply Filters — the
 *  "Upcoming Exams" preview below should always draw from the full
 *  scraped dataset regardless of what's selected in the Filters sidebar.
 *  Sidebar-driven filtering is handled separately by the "Filtered Results"
 *  card (see filteredResultExams) further up the page. */
const filteredScrapedExams = computed(() => {
  const query = searchQuery.value.trim().toLowerCase()
  return allScrapedExams.filter((exam) => {
    if (query && !exam.exam_name.toLowerCase().includes(query)) return false
    return true
  })
})

/** First few exams from the filtered dataset — a short preview, not a full page. */
const pagedExams = computed<Exam[]>(() =>
  filteredScrapedExams.value.slice(0, UPCOMING_EXAMS_LIMIT)
)

async function fetchExams(): Promise<void> {
  loading.value = true
  try {
    const params: Record<string, string | number> = { page: currentPage.value }
    const res  = await api.get<Exam[] | PaginatedResponse<Exam>>('/exams/', { params })
    const data = res.data
    if (Array.isArray(data) && data.length) {
      exams.value = data
    } else if (!Array.isArray(data) && data.results?.length) {
      exams.value = data.results
    }
  } catch (err) {
    console.error('Failed to fetch exams, falling back to scraped mock-test categories', err)
  } finally {
    loading.value = false
  }
}

// ── Search Results section (driven by the top search box) ─────────────────────

const hasSearchQuery = computed(() => searchQuery.value.trim().length > 0)

/** Exams shown in the "Search Results" card — matched against the curated
 *  popularExams list (same dataset/card shape as Filtered Results & All
 *  Exams) by name or description, across every category. */
const searchResultExams = computed(() => {
  const query = searchQuery.value.trim().toLowerCase()
  if (!query) return []
  return popularExams.filter(e =>
    e.label.toLowerCase().includes(query) ||
    e.description.toLowerCase().includes(query)
  )
})

function clearSearch(): void {
  searchQuery.value = ''
}

// ── Filtered Results section (driven by the Sidebar's "Apply Filters") ────────

const sidebarRef = ref<InstanceType<typeof Sidebar> | null>(null)
const appliedFilters: Ref<ExamFilters | null> = ref(null)
const filteredResultsRef = ref<HTMLElement | null>(null)

/** Bound to the Sidebar's "apply" event — scrolls the page up to bring the
 *  Filtered Results card into view once the user clicks Apply Filters,
 *  since the filters panel can be scrolled well below it. Waits a tick so
 *  the (v-if-gated) results section has actually rendered first. */
async function scrollToFilteredResults(): Promise<void> {
  await nextTick()
  if (filteredResultsRef.value) {
    filteredResultsRef.value.scrollIntoView({ behavior: 'smooth', block: 'start' })
  } else {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
}

const hasAppliedFilters = computed(() => {
  const f = appliedFilters.value
  if (!f) return false
  return !!(f.exam_category || f.educationLevel || f.stream || f.graduation || f.jobType || f.jobCategory)
})

/** Sidebar's "Exam Type" values ('entrance' | 'job' | 'school') map onto the
 *  category field used by popularExams ('entrance' | 'job' | 'school'). */
const EXAM_LEVEL_TO_CATEGORY: Record<string, PopularExam['category']> = {
  entrance: 'entrance',
  job: 'job',
  school: 'school',
}

const EXAM_LEVEL_LABELS: Record<string, string> = {
  entrance: 'Entrance Exam',
  job: 'Job Exam',
  school: 'School Level Exam',
}
const JOB_TYPE_LABELS: Record<string, string> = {
  government: 'Government Exam',
  it: 'IT Exam',
  non_it: 'Non-IT Exam',
  private: 'Private Exam',
}
const EDUCATION_LEVEL_LABELS: Record<string, string> = {
  '10th': '10th',
  '12th': '12th',
  diploma: 'Diploma',
  engineering: 'Engineering',
  graduation: 'Graduation',
  pg: 'Post Graduation',
}

const JOB_CATEGORY_LABELS: Record<string, string> = {
  banking: 'Banking', railways: 'Railways', defence: 'Defence / Armed Forces',
  civil_services: 'Civil Services', ssc: 'SSC / Staff Selection', teaching: 'Teaching',
  medical: 'Medical / Health', agriculture: 'Agriculture', police: 'Police',
  insurance: 'Insurance', psu: 'PSU / Engineering', law: 'Law / Legal',
  software: 'Software Development', data_science: 'Data Science / AI',
  networking: 'Networking / Cloud', cybersecurity: 'Cybersecurity', testing: 'Testing / QA',
  finance: 'Finance / Accounting', marketing: 'Marketing / Sales', hr: 'HR / Management',
  operations: 'Operations / Logistics', manufacturing: 'Manufacturing',
  media: 'Media / Journalism', retail: 'Retail / FMCG', hospitality: 'Hospitality / Tourism',
}

const examLevelChipLabel = computed(() =>
  appliedFilters.value?.exam_category ? EXAM_LEVEL_LABELS[appliedFilters.value.exam_category] ?? appliedFilters.value.exam_category : ''
)
const jobTypeChipLabel = computed(() =>
  appliedFilters.value?.jobType ? JOB_TYPE_LABELS[appliedFilters.value.jobType] ?? appliedFilters.value.jobType : ''
)
const jobCategoryChipLabel = computed(() =>
  appliedFilters.value?.jobCategory ? JOB_CATEGORY_LABELS[appliedFilters.value.jobCategory] ?? appliedFilters.value.jobCategory : ''
)
const educationLevelChipLabel = computed(() =>
  appliedFilters.value?.educationLevel ? EDUCATION_LEVEL_LABELS[appliedFilters.value.educationLevel] ?? appliedFilters.value.educationLevel : ''
)

/** Exams shown in the "Filtered Results" card.
 *  Applies all active sidebar filters: Exam Type, Qualification (educationLevel),
 *  Stream, Graduation, and Job Type. An exam must satisfy every active filter. */
const filteredResultExams = computed(() => {
  if (!hasAppliedFilters.value) return []
  const f = appliedFilters.value!
  let list = [...popularExams]

  // 1. Filter by Exam Type (entrance / job / school)
  const mappedCategory = f.exam_category ? EXAM_LEVEL_TO_CATEGORY[f.exam_category] : null
  if (mappedCategory) {
    list = list.filter(e => e.category === mappedCategory)
  }

  // 2. Filter by Job Type (government / it / non_it / private) — only meaningful for job exams
  if (f.jobType) {
    list = list.filter(e => !e.jobTypes || e.jobTypes.length === 0 || e.jobTypes.includes(f.jobType!))
  }

  // 2b. Filter by Job Category (banking / railways / defence / etc.) — sub-filter of jobType
  if (f.jobCategory) {
    list = list.filter(e => !e.jobCategories || e.jobCategories.length === 0 || e.jobCategories.includes(f.jobCategory!))
  }

  // 3. Filter by Qualification / Education Level (10th / 12th / diploma / engineering / graduation / pg)
  if (f.educationLevel) {
    list = list.filter(e => !e.educationLevels || e.educationLevels.length === 0 || e.educationLevels.includes(f.educationLevel!))
  }

  // 4. Filter by Stream (cse / mechanical / science / commerce / arts / etc.)
  if (f.stream) {
    list = list.filter(e => !e.streams || e.streams.length === 0 || e.streams.includes(f.stream!))
  }

  // 5. Filter by Graduation level (ug / pg)
  if (f.graduation) {
    list = list.filter(e => !e.graduations || e.graduations.length === 0 || e.graduations.includes(f.graduation!))
  }

  // 6. Filter by Engineering Status (graduated / pursuing) — only meaningful
  // when Qualification = Engineering; exams without this metadata (i.e. not
  // engineering-specific) are left unaffected.
  if (f.engineeringStatus) {
    list = list.filter(e => !e.engineeringStatuses || e.engineeringStatuses.length === 0 || e.engineeringStatuses.includes(f.engineeringStatus!))
  }

  return list
})

function clearAppliedFilters(): void {
  sidebarRef.value?.reset()
}

function onFilterChange(newFilters: ExamFilters): void {
  appliedFilters.value = newFilters
}
function onPageChange(page: number):  void { currentPage.value = page; fetchExams() }
function onTakeTest(exam: Exam):      void { router.push({ name: 'exam-attempt', params: { id: exam.exam_id } }) }
function onBookmark(exam: Exam):      void { exam.is_bookmarked = !exam.is_bookmarked }

onMounted(fetchExams)
</script>

<style>
/* ── Page grid ───────────────────────────────────────────────────── */
.exam-page { padding: 0; }

.exam-page-grid {
  display: grid;
  grid-template-columns: 250px 1fr 270px;
  gap: 18px;
  align-items: start;
}

.exam-page-grid > *:first-child,
.exam-page-grid > *:last-child {
  position: sticky;
  top: 80px;
}

@media (max-width: 1300px) {
  .exam-page-grid { grid-template-columns: 1fr; }
  .exam-page-grid > *:first-child,
  .exam-page-grid > *:last-child { position: static; }
}

.exam-page-main { min-width: 0; }

/* ── Search section ──────────────────────────────────────────────── */
.search-section {
  background: #fff;
  border-radius: 14px;
  padding: 18px 20px;
  margin-bottom: 16px;
  border: 1px solid #f0f0f0;
}

.section-heading { font-size: 15px; font-weight: 700; color: #1e2536; margin: 0 0 2px; }
.section-sub     { font-size: 12.5px; color: #6b7280; margin: 0 0 12px; }

.search-bar { position: relative; }
.search-ico {
  position: absolute; left: 12px; top: 50%; transform: translateY(-50%);
  width: 16px; height: 16px; color: #9ca3af;
}
.search-input {
  width: 100%; box-sizing: border-box;
  padding: 10px 14px 10px 38px;
  border: 1.5px solid #e5e7eb; border-radius: 10px;
  font-size: 13px; color: #1e2536; outline: none;
  transition: border-color 0.15s;
}
.search-input:focus { border-color: #7c3aed; }

/* ── Filtered Results (driven by the sidebar's Apply Filters) ──────── */
.filtered-results-section {
  background: #fff;
  border-radius: 14px;
  padding: 18px 20px;
  margin-bottom: 16px;
  border: 1.5px solid #ddd6fe;
  scroll-margin-top: 90px;
}

.filtered-results-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 12px;
}

.applied-filter-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
}

.filter-chip {
  background: #f5f3ff;
  border: 1px solid #ddd6fe;
  color: #6d28d9;
  font-size: 12px;
  font-weight: 600;
  padding: 5px 12px;
  border-radius: 999px;
  white-space: nowrap;
}

/* ── Popular exams ───────────────────────────────────────────────── */
.popular-section {
  background: #fff;
  border-radius: 14px;
  padding: 18px 20px;
  margin-bottom: 16px;
  border: 1px solid #f0f0f0;
}

.popular-header {
  display: flex; justify-content: space-between; align-items: flex-start;
  margin-bottom: 14px;
}

.view-all-btn {
  background: #fff; border: 1.5px solid #7c3aed; color: #7c3aed;
  font-size: 12.5px; font-weight: 600; padding: 7px 14px;
  border-radius: 8px; cursor: pointer; white-space: nowrap;
  transition: background 0.15s;
}
.view-all-btn:hover { background: #f5f3ff; }

.view-all-btn--small {
  font-size: 11.5px;
  padding: 5px 12px;
}

/* ── Category groups (shown when "All Exams" is selected) ─────────── */
.category-group { margin-bottom: 20px; }
.category-group:last-child { margin-bottom: 0; }
.category-group-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}
.category-group-title {
  font-size: 13.5px; font-weight: 700; color: #1e2536;
  margin: 0;
}

/* ── Exam category switch tabs (card + pills) ─────────────────────── */
.category-tabs-card {
  background: #fff;
  border: 1px solid #f0f0f0;
  border-radius: 12px;
  padding: 16px 18px;
  margin-bottom: 16px;
}

.category-tabs-label {
  font-size: 13px;
  font-weight: 700;
  color: #1e2536;
  margin: 0 0 12px;
}

.category-tabs-row {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.category-tab-pill {
  background: #fff;
  border: 1.5px solid #e2e2ea;
  color: #4b5165;
  font-size: 13px;
  font-weight: 600;
  padding: 9px 20px;
  border-radius: 999px;
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.15s, border-color 0.15s, color 0.15s;
}
.category-tab-pill:hover {
  border-color: #a78bfa;
  color: #7c3aed;
}
.category-tab-pill--active {
  background: #7c3aed;
  border-color: #7c3aed;
  color: #fff;
}
.category-tab-pill--active:hover {
  background: #6d28d9;
  color: #fff;
}

.popular-grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 10px;
  align-items: stretch;
}
@media (max-width: 1100px) { .popular-grid { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 700px)  { .popular-grid { grid-template-columns: repeat(2, 1fr); } }

.popular-card {
  display: flex; flex-direction: column; align-items: center; text-align: center;
  background: #fafafa; border: 1.5px solid #f0f0f0; border-radius: 12px;
  padding: 14px 8px; cursor: pointer;
  transition: border-color 0.15s, box-shadow 0.15s;
}
.popular-card:hover { border-color: #c4b5fd; box-shadow: 0 2px 12px rgba(124,58,237,0.08); }

.popular-icon {
  width: 68px; height: 68px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 8px;
  overflow: hidden;
  background: #f5f5f5;
  border: 1.5px solid #e5e7eb;
  flex-shrink: 0;
}
.popular-icon-img {
  width: 58px; height: 58px;
  object-fit: contain;
  object-position: center center;
  border-radius: 0;
  display: block;
  image-orientation: from-image;
}
.ico-purple { background: #ede9fe; }
.ico-green  { background: #d1fae5; }
.ico-orange { background: #fef3c7; }
.ico-pink   { background: #fce7f3; }
.ico-blue   { background: #dbeafe; }
.ico-violet { background: #e0e7ff; }
.ico-cyan   { background: #cffafe; }
.ico-red    { background: #fee2e2; }
.ico-indigo { background: #e0e7ff; }
.ico-teal   { background: #ccfbf1; }
.ico-yellow { background: #fef9c3; }
.ico-brown  { background: #f3e8d9; }
.ico-slate  { background: #e2e8f0; }

.popular-name  { font-size: 13px; font-weight: 700; color: #1e2536; margin: 0 0 3px; }
.popular-desc  { font-size: 10.5px; color: #6b7280; margin: 0; line-height: 1.3; flex: 1; }
.popular-count { font-size: 11px; color: #7c3aed; font-weight: 600; margin-top: 8px; }
.no-results    { text-align: center; color: #6b7280; font-size: 13px; padding: 20px 0; }

/* ── Sidebar & FeaturedAds globals (used by child components) ────── */
.panel { background: #f3f1fb; border-radius: 14px; padding: 18px; box-shadow: 0 4px 16px rgba(0,0,0,0.04); }
.panel h3 { font-size: 15px; font-weight: 700; margin: 0 0 14px; }

.filter-group { margin-bottom: 18px; }
.filter-group label { display: block; font-size: 13px; font-weight: 600; color: #1e2536; margin-bottom: 6px; }
.filter-select { width: 100%; padding: 9px 10px; border-radius: 8px; border: 1px solid #ddd; background: #fff; font-size: 13px; color: #1e2536; }

.filter-section-title { display: flex; justify-content: space-between; align-items: center; font-size: 13px; font-weight: 700; margin-bottom: 8px; }
.check-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; font-size: 13px; }
.check-row .left { display: flex; align-items: center; gap: 8px; }

.toggle { width: 34px; height: 18px; border-radius: 999px; background: #ddd6fe; position: relative; cursor: pointer; transition: background 0.2s; }
.toggle.on { background: #3b5bfd; }
.toggle::after { content: ''; position: absolute; top: 2px; left: 2px; width: 14px; height: 14px; background: #fff; border-radius: 50%; transition: transform 0.2s; }
.toggle.on::after { transform: translateX(16px); }

.section-title { font-size: 15px; font-weight: 700; margin: 0 0 14px; }

.ad-card { border-radius: 12px; padding: 14px; margin-bottom: 14px; position: relative; overflow: hidden; }
.ad-card .ad-title { font-size: 13px; font-weight: 700; margin-bottom: 4px; }
.ad-card .ad-subtitle { font-size: 11px; color: #6b7280; margin-bottom: 10px; }
.ad-card .ad-price { font-size: 13px; font-weight: 700; margin-right: 8px; }
.ad-buy-btn { background: #fff; border: none; padding: 6px 14px; border-radius: 7px; font-weight: 700; font-size: 11px; cursor: pointer; }
.ads-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.ad-card-small { border-radius: 12px; padding: 10px; }
.ad-card-small .ad-title { font-size: 11px; }
</style>