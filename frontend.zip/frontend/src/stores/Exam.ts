// Mirrors the fields returned by ExamSerializer:
// ['exam_id', 'exam_name', 'exam_year', 'conducting_body']
export interface Exam {
  exam_id: number
  exam_code: string
  exam_name: string
  exam_year: number
  conducting_body: string
  exam_category?: string
  // Optional fields used by the new list-style TestCard design.
  // Add these to ExamSerializer when ready; the UI falls back gracefully
  // with sensible defaults if they're missing from the API response.
  question_count?: number
  duration_minutes?: number
  difficulty?: 'easy' | 'medium' | 'hard'
  language?: string
  is_bookmarked?: boolean
}

export interface ExamFilters {
  exam_category: string
  exam_year: string
  stream?: string
  graduation?: string
  subject?: string
  difficulty?: string[]
}

// UI-only filter state (not yet sent to the API — see Sidebar.vue)
export interface SidebarState extends ExamFilters {
  difficulty: string[]
  language: string[]
  status: string[]
  stream: string
  graduation: string
  subject: string
}

export interface PaginatedResponse<T> {
  count: number
  next: string | null
  previous: string | null
  results: T[]
}

export type TabValue = 'all' | 'previous' | 'practice' | 'mock'

export interface TabOption {
  label: string
  value: TabValue
}

export interface CheckboxOption {
  label: string
  value: string
}